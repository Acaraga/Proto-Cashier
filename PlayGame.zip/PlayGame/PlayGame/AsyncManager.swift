//
//  AsyncManager.swift
//  PlayGame
//
//  Created by Acaraga on 02.11.16.
//  Copyright © 2016 indio. All rights reserved.
//

import Foundation
